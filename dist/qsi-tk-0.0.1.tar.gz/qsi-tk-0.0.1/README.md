# qsi

 Data science toolkit from Quality-Safety research Institute (QSI)

# Installation

> pip install qsi

# Contents

io
cs
dr