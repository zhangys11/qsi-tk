# qi

 Data science toolkit from Quality-safety research Institute (QI)

# Installation

> pip install qi

# Contents

io
cs
dr